<html>
<head>
</head>
	<body>

	</body>

</html>
<div style="border-style:solid; border-width:2px; border-color:black; width:150px">
<table>
	<tr><td><a href='useraccount.php'>Home</a></td></tr>
	<tr><td><a href='edit_profile.php'>Edit Profile</a></td></tr>
	<tr><td><a href='change_pass.php'>Change Password</a></td></tr>
	<tr><td><a href='my_order.php'>My Order</a></td></tr>
	<tr><td><a href='view_cart.php'>View Cart</a></td></tr>

</table></div>